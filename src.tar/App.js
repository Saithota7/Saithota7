import CowinDashboard from './components/CowinDashboard'

import './App.css'

const App = () => <CowinDashboard />

export default App
